package com.example.conversorreal

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.conversorreal.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(R.layout.activity_main)

        binding.buttonConverter.setOnClickListener {
            val real = binding.editReal.text.toString().toDouble()
            val dol = String.format("%.2f",real * 4.94).toDouble()

            binding.textDolar.text = "R$:${real} equivale a ${dol}$ dolares."
        }
    }
}